package com.example.gtvlauncher

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.widget.TextView

fun Context.dpi(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

class Theme(
    val name: String, val c1: String, val c2: String, val c3: String,
    val accent: String, val scrim: String
)

object Themes {
    val all = listOf(
        Theme("Graphite", "#2C2C2E", "#1C1C1E", "#000000", "#FFFFFF", "#050506"),
        Theme("Aurora", "#1E3A8A", "#3B1B6E", "#0B0B1A", "#A78BFA", "#0A0A18"),
        Theme("Midnight", "#1B2A49", "#10131C", "#07080C", "#FFFFFF", "#080B14"),
        Theme("Amoled Black", "#0A0A0A", "#000000", "#000000", "#FFFFFF", "#000000"),
        Theme("Sunset", "#4A1942", "#1E1033", "#0B0614", "#FFB86B", "#0B0614"),
        Theme("Forest", "#123524", "#0B1F16", "#050D09", "#7EE0A1", "#050D09"),
        Theme("Ocean", "#0B3C5D", "#0A1F33", "#050B14", "#5CC8FF", "#050B14"),
        Theme("Crimson", "#4A1218", "#1F0A0D", "#0A0405", "#FF6B6B", "#0A0405")
    )
    fun current(store: Store): Theme = all[store.theme.coerceIn(0, all.size - 1)]
}

fun ringDrawable(ctx: Context, oval: Boolean, color: Int, radiusDp: Int = 12): StateListDrawable {
    val focused = GradientDrawable()
    val normal = GradientDrawable()
    for (g in listOf(focused, normal)) {
        if (oval) {
            g.shape = GradientDrawable.OVAL
        } else {
            g.shape = GradientDrawable.RECTANGLE
            g.cornerRadius = ctx.dpi(radiusDp).toFloat()
        }
        g.setColor(Color.TRANSPARENT)
    }
    focused.setStroke(ctx.dpi(3), color)
    val sl = StateListDrawable()
    sl.addState(intArrayOf(android.R.attr.state_focused), focused)
    sl.addState(intArrayOf(), normal)
    return sl
}

fun roundBg(ctx: Context, color: Int, radiusDp: Int): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.RECTANGLE
    g.cornerRadius = ctx.dpi(radiusDp).toFloat()
    g.setColor(color)
    return g
}

fun pill(ctx: Context, text: String, accent: Int, onClick: () -> Unit): TextView {
    val tv = TextView(ctx)
    tv.text = text
    tv.textSize = 14f
    tv.setTextColor(Color.WHITE)
    tv.gravity = Gravity.CENTER
    tv.setPadding(ctx.dpi(18), ctx.dpi(9), ctx.dpi(18), ctx.dpi(9))
    tv.isFocusable = true
    tv.isClickable = true
    val sl = StateListDrawable()
    sl.addState(intArrayOf(android.R.attr.state_focused), roundBg(ctx, accent, 22))
    sl.addState(intArrayOf(), roundBg(ctx, Color.parseColor("#33FFFFFF"), 22))
    tv.background = sl
    tv.setOnFocusChangeListener { _, has ->
        tv.setTextColor(if (has) Color.parseColor("#101010") else Color.WHITE)
    }
    tv.setOnClickListener { onClick() }
    return tv
}

fun installedPackages(ctx: Context): Set<String> {
    val s = HashSet<String>()
    for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
        val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
        for (ri in ctx.packageManager.queryIntentActivities(q, 0)) s.add(ri.activityInfo.packageName)
    }
    return s
}

fun launchPackage(ctx: Context, pkg: String, store: Store?): Boolean {
    val pm = ctx.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg) ?: return false
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try {
        ctx.startActivity(i)
        store?.recordLaunch(pkg)
        true
    } catch (e: Exception) {
        false
    }
}
